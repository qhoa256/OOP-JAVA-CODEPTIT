package J06008_TINH_GIO_CHUAN_CHO_TUNG_GIANG_VIEN;

public class MonHoc {
    private String maMon, tenMon;

    private String gioChuan;
    public MonHoc(String maMon, String tenMon) {
        this.maMon = maMon;
        this.tenMon = tenMon;
        this.gioChuan = "";
    }

    public String getMaMon() {
        return maMon;
    }

    public String getTenMon() {
        return tenMon;
    }

    public String getGioChuan() {
        return gioChuan;
    }

    public void setGioChuan(String gioChuan) {
        this.gioChuan = gioChuan;
    }
}
