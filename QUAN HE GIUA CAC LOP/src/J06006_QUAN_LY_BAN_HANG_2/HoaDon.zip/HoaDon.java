package J06006_QUAN_LY_BAN_HANG_2;

import java.util.ArrayList;

public class HoaDon {
    private String maHD, maKH, maMH, tenKH, diaChi, tenMH;
    private long soLuong, thanhTien, loiNhuan;

    ArrayList<KhachHang> x = new ArrayList<>();
    ArrayList<MatHang> y = new ArrayList<>();

    public HoaDon(String maHD, String maKH, String maMH, long soLuong, ArrayList<KhachHang> x, ArrayList<MatHang> y) {
        this.maHD = maHD;
        this.maKH = maKH;
        this.maMH = maMH;
        this.soLuong = soLuong;
        this.x = x;
        this.y = y;
        Khach();
        Hang();
    }


    public void Khach(){
        for(KhachHang h:x){
            if(h.getMaKH().equals(this.maKH)){
                this.tenKH = h.getTenKH();
                this.diaChi = h.getDiaChi();
                return;
            }
        }
    }

    public void Hang(){
        for(MatHang q:y){
            if(q.getMaMH().equals(this.maMH)){
                this.tenMH = q.getTenMH();
                this.thanhTien = q.getGiaBan() * soLuong;
                this.loiNhuan = this.thanhTien - q.getGiaMua() * soLuong;
                return;
            }
        }
    }

    public long getLoiNhuan() {
        return loiNhuan;
    }

    public String toString(){
        return this.maHD + " " + this.tenKH + " " + this.diaChi + " " + this.tenMH + " " + this.soLuong + " " + this.thanhTien + " " + this.loiNhuan;
    }
}
