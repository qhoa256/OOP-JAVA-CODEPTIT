package J05074_DIEM_DANH_1;

public class sinhVien {
    private String maSV, hoTen, lop, diemDanh;

    public sinhVien(String maSV, String hoTen, String lop) {
        this.maSV = maSV;
        this.hoTen = hoTen;
        this.lop = lop;
    }

    public void setDiemDanh(String diemDanh) {
        this.diemDanh = diemDanh;
    }

    public String chuyenCan() {
        int res = 10;
        for (int i = 0; i < this.diemDanh.length(); i++) {
            if (this.diemDanh.charAt(i) == 'v') {
                res -= 2;
            } else if (this.diemDanh.charAt(i) == 'm') {
                res -= 1;
            }
            if (res <= 0) break;
        }
        if (res == 0) {
            return "KDDK";
        } else {
            return "" + res;
        }
    }

    public String getMaSV() {
        return maSV;
    }

    public String toString(){
        chuyenCan();
        return this.maSV + " " + this.hoTen + " " + this.lop + " " + chuyenCan();
    }
}
