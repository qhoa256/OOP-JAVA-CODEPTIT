package J05013_TUYEN_DUNG;

public class NhanVien {
    private String idNV, hoTen, lyThuyet, thucHanh;

    public NhanVien(String idNV, String hoTen, String lyThuyet, String thucHanh) {
        this.idNV = idNV;
        this.hoTen = hoTen;
        this.lyThuyet = lyThuyet;
        this.thucHanh = thucHanh;
    }

    public double diemTB() {
        double lt = 0.0;
        double th = 0.0;
        if (!this.thucHanh.contains(".") && this.thucHanh.length() > 1) {
            int x = Integer.parseInt(this.thucHanh);
            th = x / 10.0;
        }else{
            th = Double.parseDouble(this.thucHanh);
        }
        if (!this.lyThuyet.contains(".") && this.lyThuyet.length() > 1) {
            int y = Integer.parseInt(this.lyThuyet);
            lt = y / 10.0;
        }else{
            lt = Double.parseDouble(this.lyThuyet);
        }
        return (lt + th) / 2.0;
    }

    public String ketQua() {
        double x = diemTB();
        if (x > 9.5) {
            return "XUAT SAC";
        } else if (x >= 8.0) {
            return "DAT";
        } else if (x >= 5.0) {
            return "CAN NHAC";
        } else {
            return "TRUOT";
        }
    }

    public String toString(){
        return this.idNV + " " + this.hoTen + " " + String.format("%.2f", diemTB()) + " " + ketQua();
    }
}
