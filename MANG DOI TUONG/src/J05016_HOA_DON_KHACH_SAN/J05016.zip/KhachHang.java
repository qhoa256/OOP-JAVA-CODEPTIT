package J05016_HOA_DON_KHACH_SAN;

import java.time.Duration;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;

public class KhachHang {
    private String maKH, hoTen, phong, ngayNhan, ngayTra;
    private int dichVu;

    public KhachHang(String maKH, String hoTen, String phong, String ngayNhan, String ngayTra, int dichVu) {
        this.maKH = maKH;
        this.hoTen = hoTen;
        this.phong = phong;
        this.ngayNhan = ngayNhan;
        this.ngayTra = ngayTra;
        this.dichVu = dichVu;
    }

    public long soNgay(){
        LocalDate x = LocalDate.parse(ngayNhan, DateTimeFormatter.ofPattern("dd/MM/yyyy"));
        LocalDate y = LocalDate.parse(ngayTra, DateTimeFormatter.ofPattern("dd/MM/yyyy"));
        return ChronoUnit.DAYS.between(x, y) + 1;
    }

    public long tongTien(){
        String x = this.phong.substring(0, 1);
        if(x.equals("1")){
            return soNgay() * 25 + this.dichVu;
        }else if(x.equals("2")){
            return soNgay() * 34 + this.dichVu;
        }else if(x.equals("3")){
            return soNgay() * 50 + this.dichVu;
        }else{
            return soNgay() * 80 + this.dichVu;
        }
    }

    public String toString(){
        return this.maKH + " " + this.hoTen + " " + this.phong + " " + soNgay() + " " + tongTien();
    }
}
