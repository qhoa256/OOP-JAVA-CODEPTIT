package J02022_SO_XA_CACH;

public class J02022 {
    public static void main(String[] args) {

    }
}
