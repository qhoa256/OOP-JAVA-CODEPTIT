package J04006_KHAI_BAO_LOP_SINH_VIEN;

import java.util.Scanner;

public class J04006 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println(new sinhVien(sc.nextLine(), sc.nextLine(), sc.nextLine(), sc.nextDouble()));
    }
}
