package J04015_TINH_THU_NHAP_GIAO_VIEN;

import java.util.Scanner;

public class J04015 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println(new giaoVien(sc.nextLine(), sc.nextLine(), sc.nextInt()));
    }
}
