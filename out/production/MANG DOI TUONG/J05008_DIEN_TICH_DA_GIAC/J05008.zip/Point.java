package J05008_DIEN_TICH_DA_GIAC;

public class Point {
    public int x, y;

    public Point(int x, int y) {
        this.x = x;
        this.y = y;
    }
}
