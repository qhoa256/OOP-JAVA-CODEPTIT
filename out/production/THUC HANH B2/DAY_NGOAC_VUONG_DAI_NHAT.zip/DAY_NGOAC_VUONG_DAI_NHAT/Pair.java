package DAY_NGOAC_VUONG_DAI_NHAT;

public class Pair<T, U> {
    T first;
    U second;

    Pair(T first, U second) {
        this.first = first;
        this.second = second;
    }
}
