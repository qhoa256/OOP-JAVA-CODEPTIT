package J07035_BANG_DIEM_THEO_MON_HOC;

public class MonHoc {
    private String maMH, tenMH, soTinChi;

    public MonHoc(String maMH, String tenMH, String soTinChi) {
        this.maMH = maMH;
        this.tenMH = tenMH;
        this.soTinChi = soTinChi;
    }

    public String getTenMH() {
        return tenMH;
    }
}
