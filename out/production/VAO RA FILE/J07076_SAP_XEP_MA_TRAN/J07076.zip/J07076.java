package J07076_SAP_XEP_MA_TRAN;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

class Matrix {
    public int n, m, k;
    public int[][] a;

    public Matrix(int n, int m, int k) {
        this.n = n;
        this.m = m;
        this.a = new int[n][m];
        this.k = k;
    }

    public void nextMatrix(Scanner sc) {
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++)
                this.a[i][j] = sc.nextInt();
        }
    }

    public void sort() {
        for (int i = 0; i < n; i++) {
            for (int j = i; j < n; j++) {
                if (this.a[i][k - 1] > this.a[j][k - 1]) {
                    int temp = this.a[i][k - 1];
                    this.a[i][k - 1] = this.a[j][k - 1];
                    this.a[j][k - 1] = temp;
                }
            }
        }
    }

    public String toString() {
        sort();
        String s = "";
        for (int i = 0; i < this.n; i++) {
            for (int j = 0; j < this.m; j++)
                s += a[i][j] + "" + " ";
            s += "\n";
        }
        return s;
    }
}

public class J07076 {
    public static void main(String[] args) throws FileNotFoundException {
        Scanner sc = new Scanner(new File("MATRIX.in"));
        int t = sc.nextInt();
        while (t-- > 0) {
            int n = sc.nextInt(), m = sc.nextInt(), k = sc.nextInt();
            Matrix res = new Matrix(n, m, k);
            res.nextMatrix(sc);
            System.out.print(res);
        }
    }
}
