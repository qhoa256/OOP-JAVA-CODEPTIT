package CHELLO_HELLO_WORLD;

public class CHELLO {
    public static void main(String[] args) {
        System.out.println("Hello PTIT.");
    }
}
